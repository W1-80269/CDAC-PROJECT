package com.practice.project.utility;

public class Constants {
    public static final String SHARED_PREFERENCE_FILE_NAME = "Student_sp";
    public static final String LOGIN_STATUS = "login_status";
    public static final String USER_ID = "StudentID";
}
