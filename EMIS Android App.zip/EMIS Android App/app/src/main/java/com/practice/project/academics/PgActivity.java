package com.practice.project.academics;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.practice.project.R;

public class PgActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg);
    }
}