// import supportImages from ""
export const items = [
{
    title: 'Students',
    number: 0,
    takeme:"/students",
    image: 'https://img.freepik.com/free-photo/smiling-students-with-backpacks_1098-1220.jpg',
  },
  {
    title: 'Teachers',
    number: 0,
    takeme:"/teacher_details",

    image: 'https://www.hindustantimes.com/ht-img/img/2023/09/02/1600x900/teachers_day_1693652054152_1693652065719.jpg',
  },
 {
    title: 'Working Staffs',
    number: 0,
    takeme:"/non-teaching_staff_details",

    image: 'https://www.yc.edu/v6/residence-life/team-photo.jpg',
  },
{
    title: 'Classes',
    number: 13,
    takeme:"/student_details",

    image: 'https://www.cta.org/wp-content/uploads/2020/03/empty-classroom.jpg',
  },
{
    title: 'Income',
    number: 0,
    takeme:"/income",

    image: 'https://cdn.pixabay.com/photo/2022/11/08/14/59/money-7578738_1280.jpg',
  },
{
    title: 'Salary Expenses',
    number: 0,
    takeme:"/salary",

    image: 'https://resources.tallysolutions.com/us/wp-content/uploads/2021/11/cogs-vs-expenses-whats-the-difference.jpg',
  }]